#!/usr/bin/env python3
from pathlib import Path
import json,hashlib,wave,subprocess,unittest,itertools
import numpy as np
from scipy.signal import correlate,resample_poly
B=Path(__file__).resolve().parent;M=json.loads((B/'manifest.json').read_text());A=M['assets']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def samples(a):
 with wave.open(str(B/a['pcm_file']),'rb') as w:return np.frombuffer(w.readframes(w.getnframes()),'<i2').astype(float)/32767
class BankTests(unittest.TestCase):
 def test_bounded_and_no_live_resources(self):
  self.assertTrue(24<=len(A)<=40);self.assertFalse(M['native_resources_assigned']);self.assertEqual(len({a['id'] for a in A}),len(A))
 def test_source_license_and_hashes(self):
  for s in M['sources']:
   self.assertTrue(s['author'].strip());self.assertTrue(s['title'].strip());self.assertEqual(s['license'],'CC0-1.0');self.assertTrue((B/s['license_evidence']).is_file());self.assertEqual(sha(B/s['source_file']),s['sha256'])
  for a in A:self.assertEqual(sha(B/a['source_file']),a['source_file_sha256'])
 def test_ffmpeg_decodes_every_pcm(self):
  for a in A:subprocess.run(['ffmpeg','-v','error','-xerror','-i',str(B/a['pcm_file']),'-f','null','-'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
 def test_native_candidate_format(self):
  for a in A:
   with wave.open(str(B/a['pcm_file']),'rb') as w:
    self.assertEqual((w.getframerate(),w.getnchannels(),w.getsampwidth(),w.getcomptype()),(22050,1,2,'NONE'));self.assertGreater(w.getnframes(),500)
 def test_headroom_dc_and_nonempty(self):
  for a in A:
   x=samples(a);self.assertLessEqual(max(abs(x)),10**(-13.9/20));self.assertGreater(np.sqrt(np.mean(x*x)),1e-5);self.assertLess(abs(x.mean()),.003);self.assertEqual(x[0],0);self.assertEqual(x[-1],0)
 def test_trimming_and_timing(self):
  for a in A:
   self.assertLessEqual(a['audible_start_ms'],30,a['id']);self.assertLessEqual(a['duration_seconds']*1000-a['audible_end_ms'],85,a['id']);self.assertLess(a['strongest_contact_ms'],a['duration_seconds']*1000)
   if a['id'].startswith('footstep'):self.assertLessEqual(a['duration_seconds'],.181)
 def test_no_exact_duplicates(self):self.assertEqual(len({a['pcm_sha256'] for a in A}),len(A))
 def test_trim_intervals_valid(self):
  for a in A:self.assertTrue(0<=a['source_edit_start_seconds']<a['source_edit_end_seconds']<=a['source_decoded_duration_seconds']+.0001)
 def test_audition_format_and_cues(self):
  with wave.open(str(B/'audition/Everyday-Foley-Audition.wav'),'rb') as w:
   self.assertEqual((w.getframerate(),w.getnchannels(),w.getsampwidth()),(22050,1,2));duration=w.getnframes()/22050
  self.assertLess(duration,45)
  cues=json.loads((B/'audition/cue-sheet.json').read_text());self.assertEqual(len(cues),12)
  for c in cues:self.assertTrue(0<=c['start_seconds']<c['end_seconds']<duration)
if __name__=='__main__':
 comparisons=[];cache={a['id']:samples(a) for a in A}
 for a,b in itertools.combinations(A,2):
  x=cache[a['id']];y=cache[b['id']];c=float(max(abs(correlate(x,y,mode='full',method='fft')))/np.sqrt(np.sum(x*x)*np.sum(y*y)))
  if c>.90:comparisons.append({'a':a['id'],'b':b['id'],'max_normalized_cross_correlation':c,'action':'Review; normalized waveform similarity is not independent-take proof'})
 (B/'provenance/duplicate-audit.json').write_text(json.dumps({'exact_pcm_duplicates':len(A)-len({a['pcm_sha256'] for a in A}),'high_similarity_pairs':comparisons,'comparison':'Full-waveform, all relative lags, normalized cross-correlation, absolute sign; threshold 0.90','perceptual_listening_performed':False},indent=2)+'\n')
 print(json.dumps(comparisons,indent=2));unittest.main(verbosity=2)
