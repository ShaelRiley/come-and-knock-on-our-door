#!/usr/bin/env python3
"""Offline, deterministic candidate edits. No game resources or audio device access."""
from pathlib import Path
import json, subprocess, hashlib, wave, math, shutil
import numpy as np
from scipy.signal import butter, sosfilt, resample_poly
B=Path(__file__).resolve().parent; RATE=22050

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def decode(p):
 return np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(p),'-ac','1','-ar',str(RATE),'-f','f64le','-']),dtype='<f8').copy()
def save(p,x):
 y=np.clip(np.rint(x*32767),-32767,32767).astype('<i2')
 with wave.open(str(p),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(RATE);w.writeframes(y.tobytes())
 return y.astype(float)/32767
sources=json.loads((B/'provenance/fs_used_sources.json').read_text())
# 327504 was investigated but not selected: its full mechanism is too long for this compact bank.
sources=[s for s in sources if s['id']!='fs327504']
for pack,title in [('impact','Impact Sounds 1.0'),('rpg','RPG Audio')]:
 p=B/f'sources/kenney_{pack}_page.zip'
 sources.append({'id':'kenney_'+pack,'title':title,'author':'Kenney / Kenney Vleugels','source_url':'https://kenney.nl/assets/'+('impact-sounds' if pack=='impact' else 'rpg-audio'),'source_file':str(p.relative_to(B)),'sha256':sha(p),'license':'CC0-1.0','license_url':'https://creativecommons.org/publicdomain/zero/1.0/','license_evidence':f'provenance/kenney_{pack}_page.html','included_license':f'sources/kenney_{pack}_page/License.txt','retrieved_utc':'2026-10-04','original_download':True,'format_note':'Unmodified creator archive; source sound files are Ogg Vorbis'})
for s in sources:
 if s['id']=='fs805208':s['license_note']='The individual sound page explicitly lists CC0. The general profile describes attribution for CC BY sounds. Full title, author, source, license and changes are credited regardless.'
source_by_id={s['id']:s for s in sources}
items=[]
def add(id,group,source,file,label,peak=-16,crop=None,maxdur=None,anchor='action_start',note=''):
 items.append(dict(id=id,variation_group=group,source_id=source,source_file=file,label=label,target_peak_dbfs=peak,crop_seconds=crop,max_duration_seconds=maxdur,anchor=anchor,note=note))
def k(id,group,pack,file,label,peak=-16,maxdur=None,anchor='contact'):
 add(id,group,'kenney_'+pack,f'sources/kenney_{pack}_page/Audio/{file}.ogg',label,peak,maxdur=maxdur,anchor=anchor)
def fs(id,group,n,label,peak=-16,crop=None,anchor='action_start',note=''):
 add(id,group,'fs'+str(n),f'sources/freesound_{n}_hq_preview.mp3',label,peak,crop=crop,anchor=anchor,note=note)
fs('door_wood_open_a','door_open',214693,'Wooden door opening A',-15,crop=[2.05,2.85],note='Recorded wooden door; action crop selected from supplied title and waveform, pending listening')
fs('door_wood_open_b','door_open',607911,'Wooden door opening B',-15,crop=[0,0.65],note='First movement from recorded open-close pair; action identity requires listening confirmation')
fs('door_wood_close_a','door_close',607911,'Wooden door close A',-14,crop=[1.45,2.5],anchor='contact',note='Second movement from recorded open-close pair; action identity requires listening confirmation')
k('door_mechanism_open_c','door_open','rpg','doorOpen_1','Door mechanism opening C',-15,anchor='action_start')
k('door_mechanism_close_b','door_close','rpg','doorClose_1','Door mechanism close B',-14)
k('door_mechanism_close_c','door_close','rpg','doorClose_2','Door mechanism close C',-14)
fs('window_open_a','window_open',805208,'Window opening A',-16)
fs('window_wood_close_a','window_close',708683,'Wood framed window close A',-16,crop=[2.55,3.55],anchor='contact',note='Final closing contact extracted; preparatory handling omitted')
fs('window_close_b','window_close',365483,'Window close B',-16,anchor='action_start')
for i in range(3):k(f'tray_clatter_{chr(97+i)}','tray_clatter','rpg',f'metalPot{i+1}',f'Metal tray substitute {chr(65+i)}',-17,maxdur=1.5,anchor='contact')
for i in range(2):k(f'wood_object_contact_{chr(97+i)}','wood_object_contact','impact',f'impactWood_light_00{i}',f'Small wooden object contact {chr(65+i)}',-20,maxdur=.45)
for material,indices in [('wood',[0,4]),('carpet',[0,1,3]),('concrete',[0,2])]:
 for i,source_index in enumerate(indices):k(f'footstep_{material}_{chr(97+i)}',f'footstep_{material}','impact',f'footstep_{material}_00{source_index}',f'{material.capitalize()} footstep {chr(65+i)}',-25,maxdur=.18)
for i in range(2):
 k(f'impact_soft_{chr(97+i)}','impact_soft','impact',f'impactSoft_medium_00{i}',f'Soft comic impact {chr(65+i)}',-18,maxdur=.65)
 k(f'impact_hard_{chr(97+i)}','impact_hard','impact',f'impactWood_medium_00{i}',f'Hard wooden comic impact {chr(65+i)}',-14,maxdur=.7)
for i,n in enumerate([509878,566189]):fs(f'paper_pickup_{chr(97+i)}','paper_pickup',n,f'Paper handling {chr(65+i)}',-23,anchor='contact')
for i in range(2):
 k(f'cloth_handle_{chr(97+i)}','cloth_handle','rpg',f'cloth{i+1}',f'Cloth handling {chr(65+i)}',-24,maxdur=.65,anchor='action_start')
 k(f'page_turn_{chr(97+i)}','page_turn','rpg',f'bookFlip{i+1}',f'Page turn {chr(65+i)}',-23,maxdur=.75,anchor='action_start')
# Trimming is data-led, not a claim that anybody listened to the material.
for a in items:
 p=B/a['source_file']; x=decode(p);original_n=len(x)
 crop=a['crop_seconds'];start=round((crop[0] if crop else 0)*RATE);end=min(len(x),round(crop[1]*RATE)) if crop else len(x);x=x[start:end]
 x=sosfilt(butter(2,45,fs=RATE,btype='highpass',output='sos'),x)
 env=np.sqrt(np.convolve(x*x,np.ones(110)/110,'same'));threshold=max(env.max()*10**(-38/20),1e-5);active=np.flatnonzero(env>threshold)
 assert len(active),a['id']
 lead=max(0,int(active[0])-round(.006*RATE));tail=min(len(x),int(active[-1])+round(.030*RATE));x=x[lead:tail];start+=lead;end=start+len(x)
 if a['max_duration_seconds'] and len(x)>int(a['max_duration_seconds']*RATE):x=x[:int(a['max_duration_seconds']*RATE)];end=start+len(x)
 fi=min(len(x)//4,round(.002*RATE));fo=min(len(x)//4,round(.015*RATE));x[:fi]*=np.linspace(0,1,fi);x[-fo:]*=np.linspace(1,0,fo)
 point_active=np.flatnonzero(abs(x)>max(abs(x))*.01);new_end=min(len(x),int(point_active[-1])+round(.04*RATE));x=x[:new_end];end=start+len(x);x[-fo:]*=np.linspace(1,0,fo)
 gain=min(10**(18/20),10**(a['target_peak_dbfs']/20)/max(abs(x)));x*=gain
 # No dither noise is added to silent tails. Deterministic nearest PCM16 quantization.
 out=B/'pcm'/f"{a['id']}.wav";y=save(out,x)
 rmsenv=np.sqrt(np.convolve(y*y,np.ones(110)/110,'same'));contact=int(np.argmax(rmsenv));nz=np.flatnonzero(abs(y)>max(abs(y))*10**(-40/20))
 a.update(pcm_file=str(out.relative_to(B)),source_file_sha256=sha(p),pcm_sha256=sha(out),duration_seconds=round(len(y)/RATE,6),peak_dbfs=round(20*math.log10(max(abs(y))),4),rms_dbfs=round(20*math.log10(np.sqrt(np.mean(y*y))),4),source_decoded_duration_seconds=original_n/RATE,source_edit_start_seconds=start/RATE,source_edit_end_seconds=end/RATE,gain_db=20*math.log10(gain),strongest_contact_ms=round(contact/RATE*1000,2),audible_start_ms=round(nz[0]/RATE*1000,2),audible_end_ms=round(nz[-1]/RATE*1000,2),timing_note='Strongest-contact marker is algorithmic, not animation- or ear-verified; align final frame before integration',processing=['FFmpeg decoded/downmixed/resampled to mono 22050 Hz','45 Hz two-pole high-pass','relative 5 ms RMS silence trim with 6 ms pre-roll and 30 ms tail','2 ms onset and 15 ms endpoint fade','family peak ceiling with gain increase capped at 18 dB','deterministic PCM16 quantization'])
manifest={'title':'Come and Knock on Our Door everyday foley candidates','version':1,'date_utc':'2026-10-04','status':'Candidate-only offline edits; no listening, native integration or Steam Deck acceptance claimed','format':{'container':'RIFF/WAVE','rate_hz':RATE,'channels':1,'bits':16,'encoding':'signed PCM little endian'},'candidate_count':len(items),'sources':sources,'assets':items,'native_resources_assigned':False,'arbitration':'See integration-contract.md; one shared PCM lane, never layer foley voices'}
(B/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
# Spoiler-free selected audition. 750 ms section silence; same candidate levels, no normalization.
selection=[('Doors',['door_wood_open_a','door_wood_open_b','door_wood_close_a','door_mechanism_close_b']),('Windows',['window_open_a','window_wood_close_a','window_close_b']),('Metal object clatters',['tray_clatter_a','tray_clatter_b','tray_clatter_c']),('Wooden objects',['wood_object_contact_a','wood_object_contact_b']),('Wood footsteps',['footstep_wood_a','footstep_wood_b']),('Carpet footsteps',['footstep_carpet_a','footstep_carpet_b','footstep_carpet_c']),('Concrete footsteps',['footstep_concrete_a','footstep_concrete_b']),('Soft impacts',['impact_soft_a','impact_soft_b']),('Hard impacts',['impact_hard_a','impact_hard_b']),('Paper handling',['paper_pickup_a','paper_pickup_b']),('Cloth handling',['cloth_handle_a','cloth_handle_b']),('Pages',['page_turn_a','page_turn_b'])]
byid={a['id']:a for a in items};parts=[np.zeros(round(.5*RATE))];pos=len(parts[0]);cues=[]
for label,ids in selection:
 st=pos
 for id in ids:
  y=decode(B/byid[id]['pcm_file']);parts.extend([y,np.zeros(round(.24*RATE))]);pos+=len(y)+round(.24*RATE)
 cues.append({'label':label,'start_seconds':round(st/RATE,3),'end_seconds':round((pos-round(.24*RATE))/RATE,3),'assets':ids});parts.append(np.zeros(round(.75*RATE)));pos+=round(.75*RATE)
save(B/'audition'/'Everyday-Foley-Audition.wav',np.concatenate(parts));(B/'audition/cue-sheet.json').write_text(json.dumps(cues,indent=2)+'\n')
credits=['Everyday foley source credits','', 'All selected source pages explicitly list CC0 1.0. Courtesy attribution is retained.','License: https://creativecommons.org/publicdomain/zero/1.0/','Changes: selected/cropped, high-pass filtered, mono resampled, endpoint faded, level adjusted and converted to PCM16.','Freesound material uses public HQ MP3 previews, not original source WAVs. No TV/game audio or speech is included intentionally. Audible suitability and contamination still require listening.','']
for s in sources:credits+=['- '+s['title']+' by '+s['author'],s['source_url'],'CC0 1.0: '+s['license_url'],'']
credits+=['Kenney is credited as requested by the included nonmandatory credits notice.','qubodup is credited in full here even though the specific source is CC0; the profile separately describes CC BY attribution.','No source was generated with AI in this edit pipeline. The upstream creation method is only known where the creator explicitly documents it.']
(B/'CREDITS.txt').write_text('\n'.join(credits)+'\n')
lines=['Come and Knock on Our Door','Everyday foley audition and source guide','',f'{len(items)} small sound candidates for doors, windows, objects, three footstep surfaces, soft and hard impacts, paper, cloth and pages.','The audition runs at the same restrained levels as the candidates. There is no music, narration or puzzle information.','', 'Audition sections']
for c in cues:lines.append(f"{c['start_seconds']:05.2f}s  {c['label']}")
lines+=['','What is ready','- 22,050 Hz mono 16-bit WAV candidates with conservative headroom','- Different source files/crops, with exact duplicates and near-identical footstep choices excluded','- Door/window movements and softer everyday handling beside comic impacts','- Metal-pot contacts serve as tray-clatter candidates; a final tray-specific recording may fit better','', 'What still needs checking','These are source-labeled candidates and measured edits. No subjective listening or stock ScummVM playback approval is claimed. The paired wooden-door movements come from an open-close recording; confirm their action identities by ear. Window A is a modern mechanism, so its visual/material fit also needs a listen. The sound bank does not add interactions or puzzles.','', 'Sources and reuse','All selected source pages list CC0 1.0. Kenney supplied the impact/RPG packs. Freesound creators supplied wooden-door, window and paper recordings. HQ preview MP3s were used for Freesound, so these edits are not lossless source masters. Edits: cropped and trimmed, high-pass filtered, mono resampled, endpoint faded and level adjusted. Full creator credits and exact source links follow.','']+credits[7:]
(B/'delivery'/'Everyday-Foley-Source-Guide.txt').write_text('\n'.join(lines)+'\n')
shutil.copy2(B/'audition/Everyday-Foley-Audition.wav',B/'delivery/Everyday-Foley-Audition.wav')
print(json.dumps({'candidate_count':len(items),'audition_seconds':pos/RATE,'max_peak_dbfs':max(a['peak_dbfs'] for a in items)},indent=2))
