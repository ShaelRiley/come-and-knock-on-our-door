# Everyday foley candidates

Developer package: contains action bindings and may reveal physical puzzle interactions. For spoiler-free listening, use the separate audition and source guide.

A separate 31-sound candidate set plus a short spoiler-free audition for Come and Knock on Our Door. Covers wooden/house doors, windows, metal object clatters, small wood contacts, wood/carpet/concrete footsteps, soft/hard impacts, paper, cloth and pages. All selected source pages list CC0 1.0. Full source evidence, file hashes, processing and courtesy credits are retained.

The deliverable intentionally stays separate from native game data. No subjective listening, source contamination clearance by ear, native integration or stock/Steam Deck acceptance is claimed. Two door crops are inferred from the source's open-close sequence and need action-label confirmation. Metal-pot recordings are tray candidates, not a claim to be a literal tray recording. General material/action fit remains an audition decision.

- `delivery/Everyday-Foley-Audition.wav`: approximately 30 seconds, unchanged candidate gains, no music or spoilers
- `delivery/Everyday-Foley-Source-Guide.txt`: time-coded audition and source guide
- `pcm/`: standard RIFF PCM16/22050/mono, no Audio36 resource tuples
- `manifest.json`: source take/crop, format, hashes, levels and provisional timing
- `integration-contract.md`: existing committed events, timing and proposed one-lane ownership
- `CREDITS.txt`: full creator titles, source/CC0 links and modification notice
- `provenance/technical-tests.txt`, `duplicate-audit.json`: offline verification only

Rebuild offline with Python, NumPy, SciPy and FFmpeg already present:

    python3 build_bank.py
    python3 test_bank.py

The builder operates only beneath this directory; it does not open an audio device, launch ScummVM, edit game scripts or modify player settings. Sources are original Kenney Ogg packs and public Freesound HQ MP3 previews. The latter are lossy preview derivatives, not lossless source masters. The initial research also downloaded unused comparison material; only manifest-listed source files and license evidence are included in the release ZIP.

Peaks vary by intended role: approximately -14 dBFS doors/hard contacts, -16 to -17 windows/clatters, -18 soft impacts, -20 small wood, -23 paper/pages, -24 cloth and -25 footsteps. Gain increases are capped at 18 dB to avoid aggressively lifting a quiet recording. No compressor, pitch randomization, synthetic replacement or arbitrary fake variation is used. Short footstep tails fit the proposed contact cadence. Production levels must be auditioned against music on the actual device.
