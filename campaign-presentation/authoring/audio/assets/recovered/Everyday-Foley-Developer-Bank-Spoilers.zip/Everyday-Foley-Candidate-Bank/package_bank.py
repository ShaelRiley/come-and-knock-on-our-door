#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,subprocess,zipfile,tempfile,shutil
B=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tracked=[B/'manifest.json',*sorted((B/'pcm').glob('*.wav')),B/'audition/Everyday-Foley-Audition.wav',B/'audition/cue-sheet.json',B/'CREDITS.txt',B/'delivery/Everyday-Foley-Source-Guide.txt']
before={str(p.relative_to(B)):sha(p) for p in tracked}
subprocess.run(['python3',str(B/'build_bank.py')],check=True,capture_output=True)
after={str(p.relative_to(B)):sha(p) for p in tracked}
assert before==after,'Nondeterministic output'
(B/'provenance/reproducibility.json').write_text(json.dumps({'passed':True,'files':len(tracked),'sha256':after},indent=2)+'\n')
m=json.loads((B/'manifest.json').read_text())
paths={'README.md','manifest.json','integration-contract.md','CREDITS.txt','build_bank.py','test_bank.py','package_bank.py','audition/Everyday-Foley-Audition.wav','audition/cue-sheet.json','delivery/Everyday-Foley-Source-Guide.txt','provenance/technical-tests.txt','provenance/duplicate-audit.json','provenance/source-selection-notes.txt','provenance/reproducibility.json','provenance/fs_used_sources.json','provenance/qubodup_profile.html'}
for a in m['assets']:paths|={a['pcm_file'],a['source_file']}
for s in m['sources']:
 paths|={s['source_file'],s['license_evidence']}
 if s.get('included_license'):paths.add(s['included_license'])
entries=[]
for p in sorted(paths):
 q=B/p;assert q.is_file();entries.append({'file':p,'sha256':sha(q),'bytes':q.stat().st_size})
(B/'provenance/package-inputs.json').write_text(json.dumps(entries,indent=2)+'\n');paths.add('provenance/package-inputs.json')
out=B/'delivery/Everyday-Foley-Developer-Bank-Spoilers.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(paths):
  info=zipfile.ZipInfo('Everyday-Foley-Candidate-Bank/'+p,date_time=(2026,10,4,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16;z.writestr(info,(B/p).read_bytes())
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 for e in entries:assert hashlib.sha256(z.read('Everyday-Foley-Candidate-Bank/'+e['file'])).hexdigest()==e['sha256']
 report={'archive':out.name,'bytes':out.stat().st_size,'sha256':sha(out),'entries':len(z.namelist()),'verified_crc':True,'verified_payload_hashes':len(entries),'reproducible_outputs':len(tracked),'candidate_wavs':len(m['assets']),'status':'Offline package validation only'}
(B/'provenance/package-validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
