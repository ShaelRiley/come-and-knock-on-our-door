# Everyday foley integration contract

Spoiler notice: developer action bindings below may reveal physical puzzle interactions.

This is an offline candidate bank for the current stock SCI1.1 project. It does not install a runtime, change a native resource, assign Audio36 tuples, extend the puzzle model or establish native/listening acceptance. Each WAV is 22050 Hz mono signed PCM16 in RIFF/WAVE. Parent/native owner confirmed that format; keep game resource assignment with the native integrator.

## Existing committed action bindings

Event numbers below come from `stock-sci/p02-domain-adapter/manifest.json`, confirmed by the native owner on 2026-10-04. The adapter must consume a unique occurrence token, not globally suppress a repeatable event number. The same door can legitimately open and close again. No sound on an unsuccessful click, hover, inspection or initial inventory selection.

| Domain event | Physical action | Candidate group | Sync point |
|---|---|---|---|
| 8 | Window opening | window_open | First visible movement after the action is committed |
| 9 | Tray placed | tray_clatter | Tray visibly meets its support |
| 10 | Tray picked up | tray_clatter, low gain | Hand lifts the tray; avoid a heavy drop impression |
| 11 | Small wooden item picked up | wood_object_contact, low gain | Hand/object contact |
| 12 | Small wooden item placed | wood_object_contact | Object/support contact |
| 13 | Door opening | door_open | First visible door/handle movement |
| 14 | Door closing | door_close | Latch/panel reaches its closing contact |
| 200 + physical copy object ID | Paper taken | paper_pickup | Committed hand/paper contact |
| 300 + physical copy object ID | Paper placed | paper_pickup, low gain | Committed paper/support contact |

Window closing, cloth, pages and comic impacts have no new runtime hooks assigned here. They are candidate resources for already-authored physical actions only. Page sounds should be omitted for routine text UI if the animation has no physical page. Do not attach impacts to failed puzzle attempts or use SFX to hint at correctness.

## Contact timing and footstep ownership

Each asset has its source interval, audible start, duration and `strongest_contact_ms` in manifest.json. The strongest-contact value is a measured 5 ms RMS maximum; it is not a guaranteed perceptual contact. Final listening and animation alignment must confirm or override it.

For a visible action with a known future contact frame, a successful, still-current committed action may start its whole recording early enough for the verified contact to land on that frame. If the adapter exposes only an immediate contact event, use an approved contact-only edit or choose a candidate whose transient is already at its front. Do not delay gameplay to fit a recording, fire speculative sounds before success, or blindly start a 0.9-second window mechanism at the exact latch frame. In particular the modern window, page-turn A and some metal clatters contain meaningful pre-contact movement.

The existing motion controller uses four contact/pass frames at 6 SCI ticks each: contact-a/cel1 and contact-b/cel3. Potential contacts are 12 ticks apart at 60 Hz (0.2 seconds), not four steps per 0.4-second walk cycle. Emit once on an actual crossed contact frame while the actor changes position; no event on repeated redraw, standing pose, path request or arrival snap. Never catch up a backlog of missed contacts after stalls. Footstep assets are under 0.18 seconds; the actual chosen candidate must finish or be discarded before another is admitted. Footstep hooks are not implemented by this bank.

Surface labels wood, carpet and concrete are asset categories. No room-to-surface mapping is asserted. Choose the visible floor material after art review. Two or three distinct accepted candidates per surface should use a deterministic shuffled bag with immediate-repeat exclusion; serialize the small variation index/seed only if desired. Do not treat gains or pitch changes as new recorded takes.

## One shared PCM lane

This is a proposed policy, not a claim that the production arbitration is implemented or proven. Preserve separate logical Effects volume/Off; do not alter Music, Audience, speech-category global volume or the user's ScummVM/OS configuration. Keep all required feedback visible and readable with audio off.

1. Load, pause, scene skip and mute safety take precedence. Clear pending foley and never restore halfway through an obsolete one-shot
2. Active speech, if later separately authorized, is protected. Essential audible feedback must still have visual/caption feedback and may need an explicitly authored speech gap
3. An authored current audience reaction outranks decorative foley. Ordinary footsteps never replace an active laugh
4. A committed foreground object contact outranks footsteps or quiet handling, but may preempt them only through a verified safe native stop/release path. Otherwise drop the lesser new request
5. Handling and footsteps are opportunistic. Do not queue them behind speech or laughter

At most one active PCM and at most one immediate foreground request, including existing audience ownership. No parallel SFX voice, background PCM bed, independent audience stream or multi-voice mix is assumed. Compound clatters are already one file. The default safe response to a busy protected lane is to drop decorative foley, not defer it until the scene no longer matches.

## Stale-event cancellation

Each request carries room ID, scene/interaction generation, committed action occurrence token, current motion generation where relevant, contact ordinal, requested tick, owner and effect preference version. Admit it only while all ownership tokens still match. Deduplicate by occurrence token plus contact ordinal. If a newer click cancels/replaces movement, a room/apron changes, a modal/pause begins, a skip/load occurs or Effects turns Off, discard pending requests. Do not sound an abandoned target's footfall or object contact on arrival elsewhere.

Proposed age ceilings: two game ticks for footfalls and three for foreground contacts. They are scheduling tolerances to test, not guarantees of native latency. Do not accumulate missed events during a pause. An event number can occur again only for a new committed action. A saved state keeps game facts and consumed narrative events, but transient foley does not resume or replay on load. If no supported native stop can prevent an old tail, document and validate the bounded tail before integration.

## Acceptance still required

- Listen to every selected asset and verify real material/action fit, noise, voices, clipping artifacts and naturalness. Source titles/waveforms alone are insufficient
- Confirm the open/close identity of the two edited wooden-door B/A movements before binding them
- Replace the metal-pot tray stand-ins if the pictured tray sounds materially different
- Set final contact points against animation; test cancelled movement, repeat/failed actions, rapid room changes, pause, mute and manual save/load
- Test the single PCM lane with actual audience reactions and MIDI, independently mute effects, and inspect capture for double firing and stale tails
- Validate unchanged stock ScummVM and the user's actual Steam Deck listening separately. No native or device gate is passed by this asset package
