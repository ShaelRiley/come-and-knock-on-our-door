#!/usr/bin/env python3
"""Isolated, reproducible cleaner PCM bank. No runtime installation or network."""
from pathlib import Path
import hashlib, json, subprocess, wave, struct
import numpy as np
from scipy.signal import butter, sosfiltfilt, resample_poly

ROOT=Path(__file__).resolve().parent
RMS={'light':-25.,'medium':-23.,'full':-21.}
CAP={'light':1.2,'medium':2.,'full':2.8}

def db(x): return float(20*np.log10(max(float(x),1e-12)))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def decode(p, rate=48000):
    raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(p),'-ac','1','-ar',str(rate),'-f','f32le','-'])
    return np.frombuffer(raw,'<f4').astype(float)
def metrics(x, rate):
    return {'duration_seconds':round(len(x)/rate,6),'frames':len(x),'sample_rate':rate,
            'peak_dbfs':round(db(np.max(abs(x))),3),'rms_dbfs':round(db(np.sqrt(np.mean(x*x))),3),
            'dc_mean':round(float(np.mean(x)),8),'clipped_samples':int(np.count_nonzero(abs(x)>=1.))}
def write(p,x,seed):
    rng=np.random.default_rng(seed)
    y=np.rint(x*32768+rng.random(len(x))-rng.random(len(x))).astype('<i2')
    assert np.max(abs(x))<.8
    with wave.open(str(p),'wb') as w:
        w.setnchannels(1);w.setsampwidth(2);w.setframerate(22050);w.writeframes(y.tobytes())
    result=metrics(y.astype(float)/32768,22050)
    result.update(path=str(p.relative_to(ROOT)),sha256=sha(p),bytes=p.stat().st_size,
                  channels=1,bits_per_sample=16,pcm_signed=True,container='RIFF/WAVE')
    return result,y.astype(float)/32768

def build():
    (ROOT/'pcm').mkdir(exist_ok=True);(ROOT/'previews').mkdir(exist_ok=True)
    src=json.loads((ROOT/'source_index.json').read_text())
    manifest={'status':'24_source_candidate_bank_pending_bounded_cut_audition',
        'baseline':'22050 Hz, mono, signed 16-bit little-endian PCM in RIFF/WAVE',
        'texture_selection':{'user_message_id':'Sentinel_2f070910a5948191ab45333c24f554ad',
            'date_utc':'2026-10-04T21:17:37Z','choice':'cleaner 22050 PCM16 reference, not 11025 PCM8 crunch',
            'original_example_source_ids':[763960,763956,763959],
            'does_not_approve':'other sources, newly shortened cuts, or runtime acceptance'},
        'processing':'48k decode mono; DC removal;80Hz HP and6kHz LP;20ms RMS onset estimate with100ms preroll; authored duration caps; per-tier active RMS gain with-3dB ceiling;20ms cosine head/tail safety fades plus180ms settling fade for capped tails; polyphase Kaiser resample; deterministic TPDF to signed16bit. No pitch/time changes, added voices, limiter or dynamic compression.',
        'duration_caps_seconds':CAP,'target_active_rms_dbfs':RMS,
        'segmentation_qa':'Waveform-guided only. One candidate excerpt per source. No claim of human-auditioned natural boundaries or speech/music clearance.',
        'runtime_contract':{'lane_count':1,'speech_priority':True,'post_speech_gap_ticks':8,
            'pending_limit':1,'pending_expiry_ticks_after_ready':90,
            'new_input_cancels':'new utterance, skip, menu, room change, save/load',
            'cut_policy':'Immediate hard stop is the currently proven path; no runtime fade promised. File-edge fades do not prevent a click when hard-stopped midwave; native test still required.'},
        'entries':[]}
    reel=[];t=0.;cues=[];full_reel=[];full_t=0.;full_cues=[]
    for seq,s in enumerate(src,1):
        i=s['id'];tier=s['tier'];x=decode(ROOT/s['source_path'])
        sm=metrics(x,48000);sm['sha256']=sha(ROOT/s['source_path'])
        x-=np.mean(x)
        x=sosfiltfilt(butter(2,80,'highpass',fs=48000,output='sos'),x)
        x=sosfiltfilt(butter(6,6000,'lowpass',fs=48000,output='sos'),x)
        block=960;power=np.mean(x[:len(x)//block*block].reshape(-1,block)**2,axis=1)
        # Conservative automatic starting point. Listening may reject it.
        onset=int(np.flatnonzero(power>power.max()*.0625)[0])*block
        start=max(0,onset-4800);end=min(len(x),start+int(CAP[tier]*48000))
        was_capped=end<len(x)
        cut=x[start:end].copy()
        active_power=np.mean(cut[:len(cut)//block*block].reshape(-1,block)**2,axis=1)
        active=active_power>=active_power.max()*.01
        gain=min(RMS[tier]-db(np.sqrt(np.mean(active_power[active]))),-3-db(max(abs(cut))))
        cut*=10**(gain/20)
        head=min(len(cut),960);tail=min(len(cut),8640 if was_capped else 960)
        cut[:head]*=.5-.5*np.cos(np.linspace(0,np.pi,head))
        cut[-tail:]*=.5+.5*np.cos(np.linspace(0,np.pi,tail))
        out=resample_poly(cut,147,320,window=('kaiser',8.6))
        name=f'{seq:02d}_{tier}_fs{i}_22050_s16.wav'
        meta,audio=write(ROOT/'pcm'/name,out,i)
        entry={'sequence':seq,'source_take_id':f'freesound:{i}','tier':tier,
               'tier_basis':'provisional source description; listening may reclassify',
               'source':s,'source_metrics':sm,'source_start_seconds':start/48000,
               'source_end_seconds':end/48000,'tail_was_capped':was_capped,'gain_db':round(gain,4),
               'source_is_from_user_liked_example':i in (763960,763956,763959),
               'bounded_cut_user_approved':False,'listening_review':'pending','native_playback_passed':False,
               'allowed_runtime':False,'pcm':meta}
        manifest['entries'].append(entry)
        full_cues.append({'start_seconds':round(full_t,3),'end_seconds':round(full_t+len(audio)/22050,3),'sequence':seq,'source_id':i,'tier':tier})
        full_reel.extend([audio,np.zeros(round(.7*22050))]);full_t+=len(audio)/22050+.7
        if s['batch']=='expansion':
            cues.append({'start_seconds':round(t,3),'end_seconds':round(t+len(audio)/22050,3),
                         'sequence':seq,'source_id':i,'tier':tier,'name':s['title']})
            reel.extend([audio,np.zeros(round(.7*22050))]);t+=len(audio)/22050+.7
    if reel:write(ROOT/'previews/CaKoOD-clean-laughter-expansion-audition.wav',np.concatenate(reel),20261005)
    write(ROOT/'previews/CaKoOD-clean-laughter-all-24-audition.wav',np.concatenate(full_reel),20261006)
    (ROOT/'previews/all24_cue_sheet.json').write_text(json.dumps(full_cues,indent=2)+'\n')
    required=[s for s in src if '/licenses/by/4.0/' in s['license_url']]
    credit='CC BY4.0 excerpts; changes: trimming/filtering/mono/gain/resampling/fades. '+ '; '.join(s['title']+' by '+s['url'].split('/people/')[1].split('/')[0]+' '+s['url'] for s in required)+'. License https://creativecommons.org/licenses/by/4.0/ . No endorsement. Other sources CC0; see CREDITS.md.'
    for path in (ROOT/'previews').glob('*.wav'):
        b=bytearray(path.read_bytes());text=credit.encode()+b'\0'
        chunk=b'ICMT'+struct.pack('<I',len(text))+text+(b'\0' if len(text)%2 else b'')
        chunk=b'INFO'+chunk;b.extend(b'LIST'+struct.pack('<I',len(chunk))+chunk)
        b[4:8]=struct.pack('<I',len(b)-8);path.write_bytes(b)
    manifest['counts']={'source_candidates':len(src),'by_provisional_tier':{tier:sum(s['tier']==tier for s in src) for tier in RMS},
                         'new_source_candidates':sum(s['batch']=='expansion' for s in src),
                         'bounded_cuts_user_approved':0,'native_accepted':0}
    (ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    (ROOT/'previews/cue_sheet.json').write_text(json.dumps(cues,indent=2)+'\n')
    print(json.dumps({'counts':manifest['counts'],'expansion_reel_seconds':round(t,3),
        'total_pcm_bytes':sum(e['pcm']['bytes'] for e in manifest['entries'])},indent=2))

if __name__=='__main__':build()
