#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,unittest,wave
import numpy as np

ROOT=Path(__file__).resolve().parent
M=json.loads((ROOT/'manifest.json').read_text())

class CleanAudienceBank(unittest.TestCase):
    def test_counts_and_unique_sources(self):
        self.assertEqual(len(M['entries']),24)
        self.assertEqual(len({e['source_take_id'] for e in M['entries']}),24)
        self.assertEqual(M['counts']['by_provisional_tier'],{'light':8,'medium':8,'full':8})
        self.assertEqual(M['counts']['new_source_candidates'],9)
    def test_rights_and_source_bytes(self):
        licenses=[]
        for e in M['entries']:
            s=e['source'];licenses.append(s['license_url'])
            self.assertTrue(any(x in s['license_url'] for x in ('/publicdomain/zero/1.0/','/licenses/by/4.0/')))
            self.assertEqual(hashlib.sha256((ROOT/s['source_path']).read_bytes()).hexdigest(),e['source_metrics']['sha256'])
        self.assertEqual(sum('/licenses/by/4.0/' in u for u in licenses),4)
    def test_exact_pcm_and_short_limits(self):
        for e in M['entries']:
            v=e['pcm'];p=ROOT/v['path']
            self.assertEqual(hashlib.sha256(p.read_bytes()).hexdigest(),v['sha256'])
            with wave.open(str(p)) as w:
                self.assertEqual((w.getnchannels(),w.getsampwidth(),w.getframerate(),w.getcomptype()),(1,2,22050,'NONE'))
                self.assertEqual(w.getnframes(),v['frames'])
                x=np.frombuffer(w.readframes(w.getnframes()),'<i2').astype(float)/32768
            self.assertLessEqual(len(x)/22050,M['duration_caps_seconds'][e['tier']]+1/22050)
            self.assertLess(np.max(abs(x)),.75)
            self.assertLess(abs(np.mean(x)),.0002)
            self.assertLess(abs(x[0]),.0002)
            self.assertLess(abs(x[-1]),.0002)
    def test_honest_acceptance_gate(self):
        self.assertEqual(M['texture_selection']['original_example_source_ids'],[763960,763956,763959])
        self.assertEqual(sum(e['source_is_from_user_liked_example'] for e in M['entries']),3)
        for e in M['entries']:
            self.assertFalse(e['bounded_cut_user_approved'])
            self.assertFalse(e['allowed_runtime'])
            self.assertFalse(e['native_playback_passed'])
    def test_no_duplicate_windows(self):
        a=json.loads((ROOT/'waveform_duplicate_audit.json').read_text())
        self.assertEqual(len(a['pairs']),276)
        self.assertLess(max(p['max_one_second_correlation'] for p in a['pairs']),.5)
    def test_one_lane_contract(self):
        r=M['runtime_contract']
        self.assertEqual(r['lane_count'],1);self.assertEqual(r['pending_limit'],1)
        self.assertEqual(r['post_speech_gap_ticks'],8)
        self.assertEqual(r['pending_expiry_ticks_after_ready'],90)
        self.assertTrue(r['speech_priority'])

if __name__=='__main__':unittest.main(verbosity=2)
