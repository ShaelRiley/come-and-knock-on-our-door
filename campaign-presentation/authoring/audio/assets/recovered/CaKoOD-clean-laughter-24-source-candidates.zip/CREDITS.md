CaKoOD cleaner audience bank — credits and licenses

Changes: excerpts, mono downmix, filtering/DC removal, level adjustment, protective fades, resampling and PCM16 conversion. No endorsement implied. Sources downloaded as public HQ MP3 previews; original lossless masters not acquired.

Required CC BY4.0 credits
License: https://creativecommons.org/licenses/by/4.0/

Moderately Amusing.wav — Benboncan
https://freesound.org/people/Benboncan/sounds/82386/
Adapted as described above.
Laugh Crowd 1.mp3 — FunWithSound
https://freesound.org/people/FunWithSound/sounds/381375/
Adapted as described above.
Approx 800 Laugh 1.wav — lonemonk
https://freesound.org/people/lonemonk/sounds/72842/
Adapted as described above.
Approx 800 Laughter Only 1.wav — lonemonk
https://freesound.org/people/lonemonk/sounds/72843/
Adapted as described above.

Courtesy CC0 credits
CC0: https://creativecommons.org/publicdomain/zero/1.0/

AF Crowd Small Laugh.wav — mglennsound
https://freesound.org/people/mglennsound/sounds/678668/
AF Crowd Small Laugh_2.wav — mglennsound
https://freesound.org/people/mglennsound/sounds/678669/
AF Crowd Small Laugh_3.wav — mglennsound
https://freesound.org/people/mglennsound/sounds/678670/
CRWDLaff_Crowd Laughing, Reaction, Small_ShaneVincent_GSC24_BIN-AmbeoVR.wav — ShangusBurger
https://freesound.org/people/ShangusBurger/sounds/763954/
CRWDLaff_Short Polite Laugh 01_ShaneVincent_GSC24_BIN-AmbeoVR.wav — ShangusBurger
https://freesound.org/people/ShangusBurger/sounds/763960/
CRWDLaff_Short Polite Laugh 02_ShaneVincent_GSC24_BIN-AmbeoVR.wav — ShangusBurger
https://freesound.org/people/ShangusBurger/sounds/763961/
CRWDLaff_Short Polite Laugh 03_ShaneVincent_GSC24_BIN-AmbeoVR.wav — ShangusBurger
https://freesound.org/people/ShangusBurger/sounds/763962/
Small Crowd Laughing — snakebarney
https://freesound.org/people/snakebarney/sounds/138112/
CRWDLaff_Short Genuine Laugh 01_ShaneVincent_GSC24_BIN-AmbeoVR.wav — ShangusBurger
https://freesound.org/people/ShangusBurger/sounds/763956/
CRWDLaff_Short Genuine Laugh_ShaneVincent_GSC24_BIN-AmbeoVR.wav — ShangusBurger
https://freesound.org/people/ShangusBurger/sounds/763957/
CRWDLaff_Short Genuine Laugh, Reaction_ShaneVincent_GSC24_BIN-AmbeoVR.wav — ShangusBurger
https://freesound.org/people/ShangusBurger/sounds/763958/
CRWDLaff_Crowd Laughing, Reaction 01_ShaneVincent_GSC24_BIN-AmbeoVR.wav — ShangusBurger
https://freesound.org/people/ShangusBurger/sounds/763950/
CRWDLaff_Crowd Laughing, Reaction 02_ShaneVincent_GSC24_BIN-AmbeoVR.wav — ShangusBurger
https://freesound.org/people/ShangusBurger/sounds/763951/
CRWDLaff_Crowd Laughing, Reaction 03_ShaneVincent_GSC24_BIN-AmbeoVR.wav — ShangusBurger
https://freesound.org/people/ShangusBurger/sounds/763952/
CRWDLaff_Short Hearty Laugh_ShaneVincent_GSC24_BIN-AmbeoVR.wav — ShangusBurger
https://freesound.org/people/ShangusBurger/sounds/763959/
Laugh Crowd Soft.mp3 — FunWithSound
https://freesound.org/people/FunWithSound/sounds/588394/
live audience comedy show genuine laughter_moderate.wav — HowardV
https://freesound.org/people/HowardV/sounds/581528/
Voice_Crowd_Small_Expression_Laugh_Stereo — Nox_Sound
https://freesound.org/people/Nox_Sound/sounds/752711/
Laughs_ses2.wav — freesound
https://freesound.org/people/freesound/sounds/25296/
Female crowd laughing — kikorurelas
https://freesound.org/people/kikorurelas/sounds/767470/
