# Cleaner audience bank, v2 audition

## Current result

24 distinct source-recording candidates, provisionally eight each in light,
medium and full tiers. Nine sources are new; the first15 are the same recordings
as the previous bank, with new bounded cuts. **This is not24 accepted laughs.**
The user liked the earlier three-example audition and chose its cleaner
22,050Hz mono signedPCM16 RIFF/WAVE texture on4October2026. That selects the
format and gives positive feedback on those three examples; it does not approve
every other source or the newly shortened versions.

The previously delivered15-candidate files and Library versions are unchanged.
This is an isolated, separate bank. No runtime files are edited or installed.

## Sources and rights

20 sources carry CC0; four carry CC BY4.0. The required attribution entries for
Benboncan, FunWithSound and lonemonk are in CREDITS.md and the listening guide,
including titles, source links, license links and adaptation disclosures. Keep
these with distribution and in the game's credits if selected. No endorsement
is implied. CC BY applies to those audio assets, not automatically to game code.
Do not impose additional restrictions on the CC BY material.

Downloaded source bytes are Freesound public HQ MP3 previews, preserved unchanged
in sources/. Original WAV/AIFF masters are still login-gated and have not been
acquired. These copies are not mislabelled lossless masters. The source index
retains observed source and preview URLs; the manifest hashes both sources and
exports. No television/game samples, synthetic laughs, isolated-person padding,
pitch changes or alternative microphone versions are used.

Each new long source contributes exactly one candidate, not many arbitrary
snippets. Thus the54.6-second Freesound ensemble recording, the12-second theater
ensemble and the16-second comedy audience each add only one source-take ID.
Source-count conservatism is deliberate; listening still decides whether a
selected performance belongs in this game and its correct intensity.

## Processing and QA limits

PCM output: 22,050Hz mono signed16-bit. Processing retains the earlier cleaner
reference's restrained filtering/gain approach: DC removal,80Hz high-pass,
6kHz low-pass, tier-based active RMS, peak headroom, polyphase resampling and
deterministic TPDF dither. No lossy re-encoding of game PCM, dynamics compression,
pitch shifting, time stretching, invented voices or overlapping crowd layers.

The speech-system coordinator suggested duration caps of1.2/2.0/2.8s for the
three tiers. This audition follows those caps with waveform-guided onsets and
protective20ms file edges; a capped tail gets a180ms settling fade. These are
**mechanical candidate edits, not human-auditioned natural phrasing**. The source
window and processing gain are explicit per file. Reject or adjust unnatural
edits after listening rather than forcing every laugh into a cap.

This worker cannot receive audio input and has not listened. Source descriptions
and waveform evidence do not certify no speech/music, quality or naturalness.
Please review for intelligible words, performer/music bleed, conspicuous room
changes, dominant solo voices, artificial-seeming cutoffs and wrong intensity.
The CC0 label does not establish these content qualities.

Technical QA covers bytes/hashes, format, duration, peaks, DC, edge samples,
distinct source identities and a276-pair sliding waveform-overlap screen.
This is not a psychoacoustic test. Native coexistence still needs separate
testing with speech/MIDI/input/load/scene change.

## Listen

- previews/CaKoOD-clean-laughter-expansion-audition.wav: nine new sources,
  approximately26.3 seconds including0.7-second gaps. Firstlight, thenfourmedium,
  thenfourfull; cue_sheet.json gives exact windows.
- previews/CaKoOD-clean-laughter-all-24-audition.wav: all24 bounded cuts in
  numbered file order, with all24_cue_sheet.json. Useful before whole-bank signoff.
- pcm/: individual final-format candidate WAVs, labelled by sequence/tier/source.

## Integration contract, not an implementation

Speech owns the single PCM lane. One author-tagged reaction may wait for natural
speech completion, then an8-tick/133ms gap. A waiting reaction expires90ticks
after it is ready. New utterance, skip, menu, room change and save/load clear
pending laughter immediately. New input never waits for laughter. Preserve the
ordinary8-second cooldown, five-take history shared across all derivatives,
authored-tier shuffled selection and drop-if-no-eligible behavior.

An independent per-instance runtime fade is not proven. Immediate hard stop is
the currently safe control route. Pre-faded file edges help normal start/end;
they do not guarantee a midwave hard cancellation cannot click. Native testing
must establish that behavior. No multi-lane PCM or audio-engine redesign is
implied.

The original user-liked medium example remains available separately at
../native/09_medium_fs763956_22050_s16.wav (2.926s) for the isolated coexistence
fixture. It is not replaced by the2s bounded version here. The lead received its
exact path/status.

## Reproduce

Run build_clean_bank.py from local preserved sources, then test_clean_bank.py.
The waveform-overlap audit is a saved technical check. Tests do not promote any
audition or native gate to passed. Do not overwrite the immutable first delivery.
